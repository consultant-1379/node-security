/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.oss.mediation.sec.channels;

import com.ericsson.oss.itpf.sdk.modeling.eventbus.channel.annotation.ModeledChannelDefinition;
import com.ericsson.oss.itpf.sdk.modeling.eventbus.channel.annotation.ModeledChannelType;

/**
 * Defines a channel on which we send failure notifications for
 * MediationTaskResult objects. Added this as a workaround as SF modelled event
 * bus EventSender cant send a child of parent object, if/when they support we
 * can refactor this out.
 * 
 * @author etonayr
 * 
 */

@ModeledChannelDefinition(channelId = "MediationFailureResponseResultHandler", channelURI = "jms:/queue/MediationFailureResponseQueue", channelType = ModeledChannelType.POINT_TO_POINT)
public class SSHCommandFailureChannel {
}
